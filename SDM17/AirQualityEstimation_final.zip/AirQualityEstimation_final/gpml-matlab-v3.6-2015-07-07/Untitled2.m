clear;clc;
a=1;b=1;
sum = change(a, b);
disp(['a = ' num2str(a) '  b = ' num2str(b)]);
